# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'd2d45151d1dbed48fa0550f2922c9087eecb80a6b1307720ab05d82e9c18789cb3a22ae7ccdc553f4ad8a6a633e2232fdc6be78655fb61eb8bf0f77771552a06'